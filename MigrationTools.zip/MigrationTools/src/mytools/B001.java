package mytools;

import java.sql.DriverManager;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.*;
import org.xml.sax.InputSource;

import base.B000;
import base.DBGenerator;
import base.TableConfig;
import common.ForPerformanceTestConfig;
import common.ForPerformanceXMLConfig;

import java.io.IOException;
import java.sql.*;

public class B001 extends B000 {

	public static void main(String[] args) throws Exception {
/* DBConnect
		System.out.println("Test1: " + ForPerformanceTestConfig.myGetProperty("test1"));
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			Connection con = (Connection) DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl",
					"SYS as SYSDBA", "xxxxx");

			Statement stmt = ((java.sql.Connection) con).createStatement();

			ResultSet rs = stmt.executeQuery("select * from PICTURES");
			while (rs.next())
				System.out.println(rs.getInt(1) + "  " + rs.getString(2));

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
 */

		TableConfig table1 = new TableConfig();
		table1.setAll("table1");
		DBGenerator myDBGenerator = new DBGenerator();
		myDBGenerator.setTableConfig(table1);
		myDBGenerator.geneData();
		
		
		
		
	}

}
