package model;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * The persistent class for the PICTURES2 database table.
 * 
 */
public class Pictures2 implements Serializable {
	private static final long serialVersionUID = 1L;

	private BigDecimal id;

	private String picname;

	private byte[] picture;

	public Pictures2() {
	}

	public BigDecimal getId() {
		return this.id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getPicname() {
		return this.picname;
	}

	public void setPicname(String picname) {
		this.picname = picname;
	}

	public byte[] getPicture() {
		return this.picture;
	}

	public void setPicture(byte[] picture) {
		this.picture = picture;
	}

}