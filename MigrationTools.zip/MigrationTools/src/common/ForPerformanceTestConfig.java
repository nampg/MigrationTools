package common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ForPerformanceTestConfig {
//	public static final String APPNAME;
//	public static final String VERSION;
//	public static final int DEFAULT_TIMEOUT;
	
	private static Properties p = new Properties();
	static {
		try {
			p.load(new FileInputStream(System.getProperty("user.dir")+"\\src\\ForPerformanceTest.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String myGetProperty(String key) {
		return  p.getProperty(key);
	}
}
