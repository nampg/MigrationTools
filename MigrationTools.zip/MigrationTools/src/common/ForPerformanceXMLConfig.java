package common;

import java.util.ArrayList;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class ForPerformanceXMLConfig {
	protected static final InputSource inputSource = new InputSource(
			System.getProperty("user.dir") + "\\src\\ForPerformanceTest.xml");

	
	/**
	 * @param xpathExpression
	 * @param getType **content | attribute**
	 * @param attributeName
	 * @return
	 * @throws Exception
	 */
	public static String getPathStringValue(String xpathExpression)
			throws Exception {
		XPath xpath = XPathFactory.newInstance().newXPath();
		NodeList lstRoot = (NodeList) xpath.compile(xpathExpression).evaluate(inputSource, XPathConstants.NODESET);
		Element element = (Element) lstRoot.item(0);
//		System.out.println(lstRoot.getLength());
//		System.out.println("content:"+element.getTextContent());
		return element.getTextContent();
	}
	public static String getPathStringValue(String xpathExpression, int index)
			throws Exception {
		XPath xpath = XPathFactory.newInstance().newXPath();
		NodeList lstRoot = (NodeList) xpath.compile(xpathExpression).evaluate(inputSource, XPathConstants.NODESET);
		Element element = (Element) lstRoot.item(index);
//		System.out.println(lstRoot.getLength());
//		System.out.println("content:"+element.getTextContent());
		return element.getTextContent();
	}
	
	public static ArrayList<String> getPathListString(String xpathExpression)
			throws Exception {
		ArrayList<String> result = new ArrayList<String>();
		
		XPath xpath = XPathFactory.newInstance().newXPath();
		NodeList lstRoot = (NodeList) xpath.compile(xpathExpression).evaluate(inputSource, XPathConstants.NODESET);
		for(int i=0;i<lstRoot.getLength();i++) {
			Element element = (Element) lstRoot.item(i);
			result.add(element.getTextContent());
		}
//		System.out.println(lstRoot.getLength());
//		System.out.println("content:"+result.toString());
		return result;
	}
	
	public static int getLengthByPath(String xpathExpression)
			throws Exception {
		XPath xpath = XPathFactory.newInstance().newXPath();
		NodeList lstRoot = (NodeList) xpath.compile(xpathExpression).evaluate(inputSource, XPathConstants.NODESET);
		return lstRoot.getLength();
	}
	

//	public static void getxxx(String xpathExpression) throws Exception {
//		XPath xpath = XPathFactory.newInstance().newXPath();
//		// String xpathExpression =
//		// "/table1/SubTables/SubTable/RelationColumns/RelationColumn";
//
//		NodeList lstRoot = (NodeList) xpath.compile(xpathExpression).evaluate(inputSource, XPathConstants.NODESET);
////        NodeList lstChilds = lstRoot.item(0).getChildNodes();
//		System.out.println("Number Of Node:" + lstRoot.getLength());
//
//		for (int i = 0; i < lstRoot.getLength(); i++) {
//			Element xx = (Element) lstRoot.item(i);
//
//			System.out.println("**************************START*****************************");
//			System.out.println("getLocalName:" + lstRoot.item(i).getLocalName());
//			System.out.println("getTextContent:" + lstRoot.item(i).getTextContent());
//			System.out.println("getTextContent:" + xx.getAttribute("originalColumnName"));
//			System.out.println("getTextContent:" + xx.getAttribute("destinalColumnName"));
//			System.out.println("--------------------------END-------------------------------");
//
//		}
//	}
//	
//	
}
