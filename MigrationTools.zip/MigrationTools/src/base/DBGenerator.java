package base;

import java.util.ArrayList;
import java.util.Set;

public class DBGenerator {
	protected TableConfig tableConfig;

	public TableConfig getTableConfig() {
		return tableConfig;
	}

	public void setTableConfig(TableConfig tableConfig) {
		this.tableConfig = tableConfig;
	}

	public void geneData() {
		for (int i = 0; i < tableConfig.getNumberOfRowsToInsert(); i++) {
			String sql = "INSERT INTO " + tableConfig.getTableName();
			tableConfig.getUniquePrimaryKey();
			sql += tableConfig.getRecord();

			System.out.println(sql);
		}

	}
}
