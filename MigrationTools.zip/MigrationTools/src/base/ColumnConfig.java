package base;

import java.util.ArrayList;
import java.util.Random;

public class ColumnConfig {
	protected String columnName;
	protected String dataType;
	protected int maxLength;
	protected boolean fakeConfig;
	protected String randomFrom;
	protected String randomTo;
	protected String defaultValue;
	protected String randomValue;

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public int getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}

	public boolean isFakeConfig() {
		return fakeConfig;
	}

	public void setFakeConfig(boolean fakeConfig) {
		this.fakeConfig = fakeConfig;
	}

	public String getRandomFrom() {
		return randomFrom;
	}

	public void setRandomFrom(String randomFrom) {
		this.randomFrom = randomFrom;
	}

	public String getRandomTo() {
		return randomTo;
	}

	public void setRandomTo(String randomTo) {
		this.randomTo = randomTo;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getRandomValue() {
		return randomValue;
	}

	public void setRandomValue(String randomValue) {
		this.randomValue = randomValue;
	}

	public String getRandomString() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(maxLength);
		for (int i = 0; i < maxLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		this.randomValue = buffer.toString();

		return this.randomValue;
	}

}
