package base;

import java.util.ArrayList;
import java.util.HashMap;

import common.ForPerformanceXMLConfig;

public class TableConfig {
	protected String tableName;
	protected String objectName;
	protected int numberOfRowsToInsert;
	protected ArrayList<String> primaryKeys;
	protected HashMap<String, ColumnConfig> columns;

	protected ArrayList<TableConfig> subTables;

	protected ArrayList<String> uniqueList = new ArrayList<String>();
	
	public String getTableName() {
		return tableName;
	}

	public String getObjectName() {
		return objectName;
	}

	public int getNumberOfRowsToInsert() {
		return numberOfRowsToInsert;
	}

	public ArrayList<String> getPrimaryKeys() {
		return primaryKeys;
	}

	public HashMap<String, ColumnConfig> getColumns() {
		return columns;
	}

	public ArrayList<TableConfig> getSubTables() {
		return subTables;
	}

	/*
	 * Setter
	 */

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public void setNumberOfRowsToInsert(int numberOfRowsToInsert) {
		this.numberOfRowsToInsert = numberOfRowsToInsert;
	}

	public void setPrimaryKeys(ArrayList<String> primaryKeys) {
		this.primaryKeys = primaryKeys;
	}

	public void setColumns(HashMap<String, ColumnConfig> columns) {
		this.columns = columns;
	}

	public void setSubTables(ArrayList<TableConfig> subTables) {
		this.subTables = subTables;
	}

	/*
	 * Setter by XML
	 */

	public void setObjectName() throws Exception {
		this.objectName = ForPerformanceXMLConfig.getPathStringValue(//
				"/Tables/Table[@tablename='" + this.tableName + "']/ObjectName");
	}

	public void setNumberOfRowsToInsert() throws Exception {
		this.numberOfRowsToInsert = Integer.parseInt(ForPerformanceXMLConfig.getPathStringValue(//
				"/Tables/Table[@tablename='" + this.tableName + "']/NumberOfRowsToInsert"));
	}

	public void setPrimaryKeys() throws Exception {
		this.primaryKeys = ForPerformanceXMLConfig.getPathListString(//
				"/Tables/Table[@tablename='" + this.tableName + "']/PrimaryKeys/PrimaryKey");
	}

	public void setColumns() throws Exception {
		this.columns = new HashMap<String, ColumnConfig>();
		String columnPath = "/Tables/Table[@tablename='" + this.tableName + "']/Columns/Column";
		int columnLength = ForPerformanceXMLConfig.getLengthByPath(columnPath);
//		System.out.println("Number of Column:"+columnLength);
		for(int i = 0; i<columnLength; i++) {
			ColumnConfig tempColumnConfig = new ColumnConfig();
			String tempColumnName = ForPerformanceXMLConfig.getPathStringValue(columnPath+"/ColumnName", i);
			tempColumnConfig.setColumnName(tempColumnName);
			tempColumnConfig.setDataType(ForPerformanceXMLConfig.getPathStringValue(columnPath+"/DataType", i));
			tempColumnConfig.setMaxLength(Integer.parseInt(ForPerformanceXMLConfig.getPathStringValue(columnPath+"/MaxLength", i)));
			tempColumnConfig.setFakeConfig(Boolean.parseBoolean(ForPerformanceXMLConfig.getPathStringValue(columnPath+"/FakeConfig", i)));
			tempColumnConfig.setRandomFrom(ForPerformanceXMLConfig.getPathStringValue(columnPath+"/RandomFrom", i));
			tempColumnConfig.setRandomTo(ForPerformanceXMLConfig.getPathStringValue(columnPath+"/RandomTo", i));
			tempColumnConfig.setDefaultValue(ForPerformanceXMLConfig.getPathStringValue(columnPath+"/DefaultValue", i));
			tempColumnConfig.setRandomValue(ForPerformanceXMLConfig.getPathStringValue(columnPath+"/DefaultValue", i));
			this.columns.put(tempColumnName, tempColumnConfig);
			System.out.println(this.columns.get(tempColumnName).getColumnName());
			System.out.println("***************************");
		}
		
	}

//	public void setSubTables() throws Exception {
//		this.subTables = new ArrayList<TableConfig>();
//		String columnPath = "/Tables/Table[@tablename='" + this.tableName + "']/SubTables/SubTable";
//		int subTablesLength = ForPerformanceXMLConfig.getLengthByPath(columnPath);
////		System.out.println("Number of Column:"+columnLength);
//		for(int i = 0; i<subTablesLength; i++) {
//			
//		}
//	}
	
	public void setAll(String tableName) throws Exception {
		this.setTableName(tableName);
		this.setObjectName();
		this.setNumberOfRowsToInsert();
		this.setPrimaryKeys();
		this.setColumns();
	}
	
	public String getUniquePrimaryKey() {
		String resurt = "";
		boolean isUnique = false;
		while(!isUnique) {
			String tempKeys = "";
			for(int i= 0; i<this.primaryKeys.size(); i++) {
				tempKeys+=this.columns.get(this.primaryKeys.get(i)).getRandomString();
			}
			if(!uniqueList.contains(tempKeys)) {
				this.uniqueList.add(tempKeys);
				isUnique=true;
			}
		}
		return resurt;
	}
	
	public String getRecord() {
		String resultKeys = "(";
		String resultValues = "";
		for(String key : this.getColumns().keySet()) {
			resultKeys += key+", ";
			resultValues+="'"+this.getColumns().get(key).getRandomValue()+"', ";
		}
		return resultKeys+") VALUES ("+resultValues+")";
	}

}
